WELCOME WONDERHUB — TAMIL NADU TOURISM EXPLORER

Files:
- index.html: website sections and enquiry form
- style.css: responsive design
- script.js: destination data, search, district/category filters, See More, saved places, details modal and email enquiry

HOW TO RUN:
1. Extract the ZIP.
2. Keep index.html, style.css, and script.js in the same folder.
3. Open index.html in Chrome or use VS Code Live Server.

FEATURES:
- Responsive homepage / navigation
- 17 featured Tamil Nadu destinations
- Search by place, district, category, and keywords
- District and experience filters
- See More / See Fewer destinations
- Destination details modal
- Save / unsave places during the current session
- District tiles that filter the destination list
- Trip enquiry form prepares an email via the user's mail app

IMPORTANT:
This is a front-end college project demo. It does not confirm reservations, take payments, or save data to a server. Connect a backend and business email for live booking. Destination images and Google Fonts are loaded externally and need internet access. Verify local conditions, timings, and travel advice before visiting destinations.
